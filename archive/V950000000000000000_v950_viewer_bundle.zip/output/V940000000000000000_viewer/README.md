Open index.html. Candidate viewer only; projection/metrics are auxiliary.
