# V990 allowed claim statement

Allowed claim level: Level 2 - advisor defense ready on current sequence/frame.

Allowed:
- Contrastive canonical SMPL-X surfel student is advisor-defense locked for the current 0021_03 sequence/frame.
- Main evidence is a transported full-scene RGB point cloud with human as subject and partial environment.
- V591/Kinect/dense SMPL-X/canonical diagnostics are not final output.

Not allowed:
- promotion ready
- paper-grade multi-sequence generalization
- semantic label causality strong across all settings
- teacher/Kinect final output
